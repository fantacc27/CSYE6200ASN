/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

/**
 *
 * @author Xiao
 */
public class CARule {

    private CAFlakeCell[][] cafc = null;

    public static void display(CAFlakeCell[][] c) {
        for (int i = 1; i < c.length-1; i++) {
            for (int j = 1; j < c.length-1; j++) {

                System.out.print(c[i][j].cellshape);
            }
            System.out.println();
        }
    }

    private CAFlakeCell[][] initFlake() {

        CAFlake cafinit = new CAFlake();
        CAFlakeCell[][] Flake = cafinit.getFlake();
        for (int i = 0; i < 67; i++) {
            for (int j = 0; j < 67; j++) {

                Flake[i][j] = new CAFlakeCell();
                Flake[i][j].CAFlakeJudge(0);

            }
        }

        Flake[33][33].CAFlakeJudge(1);

        return Flake;
    }

    private CAFlakeCell[][] generateNextFlake(CAFlakeCell[][] Flake) {
        //CAFlake cafnext = new CAFlake();
        //CAFlakeCell[][] Flake = cafnext.getFlake();

        for (int i = 1; i < 66; i++) {
            for (int j = 1; j < 66; j++) {
                //Flake[i][j] = new CAFlakeCell();
                //Flake[i + 1][j] = new CAFlakeCell();
                //Flake[i - 1][j] = new CAFlakeCell();
                //Flake[i][j + 1] = new CAFlakeCell();
                //Flake[i][j - 1] = new CAFlakeCell();
                if (Flake[i][j].cellshape == "\u25A0") {
                    continue;
                }/*else if(i == 1){
                    Flake[0][j].cellshape = "\u25A1";
                } else if(i == 63){
                    Flake[64][j].cellshape = "\u25A1"
                }*/ else {
                    int count = 0;
                    if (Flake[i + 1][j].cellshape == "\u25A0") {
                        count++;
                    }
                    if (Flake[i - 1][j].cellshape == "\u25A0") {
                        count++;
                    }
                    if (Flake[i][j + 1].cellshape == "\u25A0") {
                        count++;
                    }
                    if (Flake[i][j - 1].cellshape == "\u25A0") {
                        count++;
                    }
                    if (count == 1 || count == 3) {
                        Flake[i][j].eorf = true;

                    }
                }
            }
        }
        for (int i = 0; i < 67; i++) {
            for (int j = 0; j < 67; j++) {
                if (Flake[i][j].eorf == true) {
                    Flake[i][j].cellshape = "\u25A0";
                }
            }
        }

        return Flake;

    }

    public CAFlakeCell[][] getNextFlake(int a) {
        cafc = initFlake();
        for (int i = 0; i < a; i++) {
            cafc = generateNextFlake(cafc);
        }
        return cafc;
    }

    public CAFlakeCell[][] getInitFlake() {
        return initFlake();
    }

}
